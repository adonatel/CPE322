def greet(name):
    print("Hello, {0}!".format(name))
print("What's your name?")
name = raw_input()
greet(name)
