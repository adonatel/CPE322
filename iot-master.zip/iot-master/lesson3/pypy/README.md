```sh
$ gcc -o test test.c

$ time ./test

$ time pypy test.py

$ time python test.py

$ time python3 test.py

$ pypy -m cProfile test.py

$ python -m cProfile test.py

$ python3 -m cProfile test.py
```
